(function($){
 
    $.fn.shuffle = function() {
 
        var allElems = this.get(),
            getRandom = function(max) {
                return Math.floor(Math.random() * max);
            },
            shuffled = $.map(allElems, function(){
                var random = getRandom(allElems.length),
                    randEl = $(allElems[random]).clone(true)[0];
                allElems.splice(random, 1);
                return randEl;
           });
 
        this.each(function(i){
            $(this).replaceWith($(shuffled[i]));
        });
 
        return $(shuffled);
 
    };
 
})(jQuery);

const NameOfSuits = ['club', 'spade', 'heart', 'diamond'];
const CardsInASuit = ['11','12','13','1','2','3','4','5','6','7','8','9','10'];

var cards_div;
$(function(){
	createDeck();
})

//Clubs, Spades, Hearts, Diamonds
function createDeck(){
	var clubs_div;
	
	for(var i=0; i< NameOfSuits.length; i++){
		
		for(var j=1; j<= CardsInASuit.length; j++){
			
			var dynId = NameOfSuits[i]+'_'+j;
			var imgUrl = 'css/imgs/'+NameOfSuits[i]+'.jpg';
			
			cards_div = $('<div class="card" id="'+'000'+i+j+'" onclick="moveThisCard(this);"><img src="'+imgUrl+'"><label style="float:right;">'+(NameOfSuits[i])+' '+j+'</label></div>');
			//cards.push(cards_div);
			$("#card_div").append(cards_div);
		}
	}
			
	
}


function sortCards(){

	var $wrapper = $('#removed_card'),
        $cards = $wrapper.find('.card');
    [].sort.call($cards, function(a,b) {
        return +$(a).attr('id') - +$(b).attr('id');
    });
    $cards.each(function(){
        $wrapper.append(this);
    });
	
}

function shuffleCards(){
	$("#card_div").find(".card").shuffle();
}
function moveThisCard(th){
	var parDiv = $(th).parent().attr('id');
	if(parDiv !== 'removed_card' ){
		$("#removed_card").append($(th).remove());
	}else{
		$("#card_div").append($(th).remove());
	}
}



